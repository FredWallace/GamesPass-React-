import React, { useState } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
  useWindowDimensions,
} from 'react-native';

const HANGMAN_WORDS = [
  'MADRASTA',
  'REACT',
  'QUIMICA',
  'ORNITORRINCO',
  'PARAGUAI',
  'BRASILIA',
  'NATIVE',
  'MATINAL',
  'JABUTICABA',
  'NATUREZA',
];

const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
const PUZZLE_SIZE = 3;
const MAX_WRONG = 6;

export default function App() {
  const [screen, setScreen] = useState('home');

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {screen === 'home' && <HomeScreen onOpenScreen={setScreen} />}
        {screen === 'forca' && <HangmanScreen onBack={() => setScreen('home')} />}
        {screen === 'jogodavelha' && <TicTacToeScreen onBack={() => setScreen('home')} />}
        {screen === 'quebracabeca' && <Quebracabeca onBack={() => setScreen('home')} />}
      </View>
    </SafeAreaView>
  );
}

function HomeScreen({ onOpenScreen }) {
  const { width } = useWindowDimensions();
  const bigScreen = width > 700;

  return (
    <View style={styles.homeWrapper}>
      <Text style={styles.title}>Passa tempo</Text>
      <Text style={styles.subtitle}>Escolha o jogo e divirta-se.</Text>

      <View
        style={[
          styles.menuBox,
          { width: bigScreen ? 500 : '100%' },
        ]}
      >
        <MenuButton
          title="Forca"
          color="#4f46e5"
          onPress={() => onOpenScreen('Forca')}
        />
        <MenuButton
          title="Jogo da velha"
          color="#059669"
          onPress={() => onOpenScreen('jogodavelha')}
        />
        <MenuButton
          title="Quebra Cabeça"
          color="#ea580c"
          onPress={() => onOpenScreen('quebracabeca')}
        />
      </View>
    </View>
  );
}

function MenuButton({ title, color, onPress }) {
  return (
    <TouchableOpacity style={[styles.menuButton, { backgroundColor: color }]} onPress={onPress}>
      <Text style={styles.menuButtonText}>{title}</Text>
    </TouchableOpacity>
  );
}

function SmallButton({ title, onPress, color = '#334155' }) {
  return (
    <TouchableOpacity style={[styles.smallButton, { backgroundColor: color }]} onPress={onPress}>
      <Text style={styles.smallButtonText}>{title}</Text>
    </TouchableOpacity>
  );
}

function ScreenHeader({ title, onBack }) {
  return (
    <View style={styles.headerRow}>
      <SmallButton title="Back" onPress={onBack} color="#1f2937" />
      <Text style={styles.screenTitle}>{title}</Text>
      <View style={{ width: 70 }} />
    </View>
  );
}

function HangmanScreen({ onBack }) {
  const { width } = useWindowDimensions();
  const [word, setWord] = useState(getRandomWord());
  const [guessedLetters, setGuessedLetters] = useState([]);

  const wrongLetters = guessedLetters.filter((letter) => !word.includes(letter));
  const wrongCount = wrongLetters.length;

  const isWon = word.split('').every((letter) => guessedLetters.includes(letter));
  const isLost = wrongCount >= MAX_WRONG;

  const shownWord = word
    .split('')
    .map((letter) => (guessedLetters.includes(letter) || isLost ? letter : '_'))
    .join(' ');

  const letterButtonSize = Math.min((width - 50) / 7, 48);

  function onGuess(letter) {
    if (guessedLetters.includes(letter) || isWon || isLost) return;
    setGuessedLetters([...guessedLetters, letter]);
  }

  function resetGame() {
    setWord(getRandomWord());
    setGuessedLetters([]);
  }

  return (
    <ScrollView contentContainerStyle={styles.scrollContent}>
      <ScreenHeader title="Forca" onBack={onBack} />

      <View style={styles.card}>
        <Text style={styles.infoText}>Palpites errados: {wrongCount} / {MAX_WRONG}</Text>
        <Text style={styles.hangmanFace}>{getRosto(wrongCount)}</Text>
        <Text style={styles.wordText}>{shownWord}</Text>

        {isWon && <Text style={styles.successText}>Você venceu!</Text>}
        {isLost && <Text style={styles.errorText}>Você perdeu! A palavra é : {word}</Text>}

        <Text style={styles.infoText}>Letras erradas: {wrongLetters.join(', ')}</Text>

        <View style={styles.lettersWrap}>
          {ALPHABET.map((letter) => {
            const used = guessedLetters.includes(letter);
            return (
              <TouchableOpacity
                key={letter}
                onPress={() => onGuess(letter)}
                disabled={used || isWon || isLost}
                style={[
                  styles.letterButton,
                  {
                    width: letterButtonSize,
                    height: letterButtonSize,
                    opacity: used || isWon || isLost ? 0.4 : 1,
                    backgroundColor: used ? '#94a3b8' : '#2563eb',
                  },
                ]}
              >
                <Text style={styles.letterText}>{letter}</Text>
              </TouchableOpacity>
            );
          })}
        </View>

        <SmallButton title="Reiniciar" onPress={resetGame} color="#4f46e5" />
      </View>
    </ScrollView>
  );
}

function TicTacToeScreen({ onBack }) {
  const { width } = useWindowDimensions();
  const [board, setBoard] = useState(Array(9).fill(null));
  const [xTurn, setXTurn] = useState(true);

  const winner = getWinner(board);
  const draw = !winner && board.every((cell) => cell !== null);
  const boxSize = Math.min((width - 40) / 3, 120);

  function onPressCell(index) {
    if (board[index] || winner) return;

    const newBoard = [...board];
    newBoard[index] = xTurn ? 'X' : 'O';
    setBoard(newBoard);
    setXTurn(!xTurn);
  }

  function resetGame() {
    setBoard(Array(9).fill(null));
    setXTurn(true);
  }

  let statusText = `Jogador: ${xTurn ? 'X' : 'O'}`;
  if (winner) statusText = `Vencedor ${winner}`;
  if (draw) statusText = 'Empate';

  return (
    <ScrollView contentContainerStyle={styles.scrollContent}>
      <ScreenHeader title="Jogo da Velha" onBack={onBack} />

      <View style={styles.card}>
        <Text style={styles.infoText}>{statusText}</Text>

        <View style={styles.board}>
          {board.map((cell, index) => (
            
          ))}
        </View>

        <SmallButton title="Reiniciar" onPress={} color="#059669" />
      </View>
    </ScrollView>
  );
}

function Quebracabeca({ onBack }) {
  const { width } = useWindowDimensions();
  const [imageUrl, setImageUrl] = useState(ImagemAleatoriaUrl());
  const [pieces, setPieces] = useState(embaralhar());
  const [selectedIndex, setSelectedIndex] = useState(null);
  const [moves, setMoves] = useState(0);

  const boardSize = Math.min(width - 30, 360);
  const tileSize = boardSize / PUZZLE_SIZE;
  const referenceSize = Math.min(width - 40, 220);

  const solved = pieces.every((value, index) => value === index);

  function NovoQuebraCabeca(withNewImage = false) {
    if (withNewImage) {
      setImageUrl(ImagemAleatoriaUrl());
    }
    setPieces(embaralhar());
    setSelectedIndex(null);
    setMoves(0);
  }

  function onPressPiece(index) {
    if (solved) return;

    if (selectedIndex === null) {
      setSelectedIndex(index);
      return;
    }

    if (selectedIndex === index) {
      setSelectedIndex(null);
      return;
    }

    const newPieces = [...pieces];
    const temp = newPieces[selectedIndex];
    newPieces[selectedIndex] = newPieces[index];
    newPieces[index] = temp;

    setPieces(newPieces);
    setSelectedIndex(null);
    setMoves(moves + 1);
  }

  return (
    <ScrollView contentContainerStyle={styles.scrollContent}>
      <ScreenHeader title="Quebra-cabeça" onBack={onBack} />

      <View style={styles.card}>
        <Text style={styles.infoText}>Imagem de referência</Text>
        <Image
          source={{ uri: imageUrl }}
          style={[styles.referenceImage, { width: referenceSize, height: referenceSize }]}
        />

        <Text style={styles.infoText}>Toque em uma peça e, em seguida, toque em outra peça para trocá-las..</Text>
        <Text style={styles.infoText}>Movimentos: {moves}</Text>
        {solved && <Text style={styles.successText}>Quebra cabeça resolvido!</Text>}

        <View style={[styles.puzzleBoard, { width: boardSize, height: boardSize }]}>
          {pieces.map((pieceNumber, index) => {
            const row = Math.floor(pieceNumber / PUZZLE_SIZE);
            const col = pieceNumber % PUZZLE_SIZE;

            return (
              <TouchableOpacity
                key={index}
                onPress={() => onPressPiece(index)}
                style={[
                  styles.puzzleTile,
                  {
                    width: tileSize,
                    height: tileSize,
                    borderColor: selectedIndex === index ? '#ef4444' : '#ffffff',
                  },
                ]}
              >
                <View style={{ width: tileSize, height: tileSize, overflow: 'hidden' }}>
                  <Image
                    source={{ uri: imageUrl }}
                    style={{
                      width: boardSize,
                      height: boardSize,
                      position: 'absolute',
                      left: -col * tileSize,
                      top: -row * tileSize,
                    }}
                  />
                </View>
              </TouchableOpacity>
            );
          })}
        </View>

        <View style={styles.buttonRow}>
          <SmallButton title="Embaralhar" onPress={() => NovoQuebraCabeca(false)} color="#ea580c" />
          <SmallButton title="Nova imagem" onPress={() => NovoQuebraCabeca(true)} color="#7c3aed" />
        </View>
      </View>
    </ScrollView>
  );
}

function getRandomWord() {
  const randomIndex = Math.floor(Math.random() * HANGMAN_WORDS.length);
  return HANGMAN_WORDS[randomIndex];
}

function getWinner(board) {
  const lines = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];

  for (let i = 0; i < lines.length; i++) {
    const [a, b, c] = lines[i];
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return board[a];
    }
  }

  return null;
}

function ImagemAleatoriaUrl() {
  const seed = Math.floor(Math.random() * 100000);
  return `https://picsum.photos/seed/${seed}/600/600`;
}

function embaralhar() {
  const array = Array.from({ length: PUZZLE_SIZE * PUZZLE_SIZE }, (_, i) => i);

  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const temp = array[i];
    array[i] = array[j];
    array[j] = temp;
  }

  // if by chance it is already solved, swap two pieces
  const alreadySolved = array.every((value, index) => value === index);
  if (alreadySolved) {
    const temp = array[0];
    array[0] = array[1];
    array[1] = temp;
  }

  return array;
}

function getRosto(count) {
  const faces = ['🙂', '😐', '😟', '😣', '😫', '😵', '💀'];
  return faces[count];
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#e2e8f0',
  },
  container: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 30,
  },
  homeWrapper: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: '700',
    textAlign: 'center',
    color: '#0f172a',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    textAlign: 'center',
    color: '#475569',
    marginBottom: 24,
  },
  menuBox: {
    alignSelf: 'center',
  },
  menuButton: {
    paddingVertical: 18,
    borderRadius: 14,
    marginBottom: 14,
    alignItems: 'center',
  },
  menuButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '700',
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  screenTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#0f172a',
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 18,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  infoText: {
    fontSize: 16,
    color: '#334155',
    marginBottom: 10,
    textAlign: 'center',
  },
  hangmanFace: {
    fontSize: 56,
    marginBottom: 10,
  },
  wordText: {
    fontSize: 30,
    fontWeight: '700',
    letterSpacing: 3,
    marginBottom: 16,
    color: '#111827',
    textAlign: 'center',
  },
  successText: {
    color: '#15803d',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 10,
    textAlign: 'center',
  },
  errorText: {
    color: '#b91c1c',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 10,
    textAlign: 'center',
  },
  lettersWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    marginBottom: 16,
  },
  letterButton: {
    margin: 4,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  letterText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '700',
  },
  board: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    width: '100%',
    justifyContent: 'center',
    marginVertical: 14,
  },
  cell: {
    borderWidth: 2,
    borderColor: '#0f172a',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  cellText: {
    fontSize: 38,
    fontWeight: '700',
    color: '#0f172a',
  },
  referenceImage: {
    borderRadius: 12,
    marginBottom: 14,
    backgroundColor: '#cbd5e1',
  },
  puzzleBoard: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 6,
    marginBottom: 16,
    backgroundColor: '#cbd5e1',
  },
  puzzleTile: {
    borderWidth: 2,
  },
  buttonRow: {
    width: '100%',
    alignItems: 'center',
  },
  smallButton: {
    minWidth: 120,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginVertical: 6,
  },
  smallButtonText: {
    color: 'white',
    fontSize: 15,
    fontWeight: '700',
  },
});
